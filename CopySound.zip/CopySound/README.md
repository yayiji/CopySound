# CopySound
A copy sound effect for Windows.

You can choose your own sound by replacing the sound.wav file.
